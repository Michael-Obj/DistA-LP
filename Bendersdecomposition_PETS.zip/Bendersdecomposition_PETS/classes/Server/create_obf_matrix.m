function create_obf_matrix(distance_matrix, cost_matrix)

end