function server = create_CRTable(server, env_parameters, LR_loc_ID)
end